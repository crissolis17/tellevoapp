import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {
  username: string ='';  // Esto debería venir de un servicio de autenticación en una app real

  constructor(private router: Router) {}

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras && navigation.extras.state) {
      this.username = navigation.extras.state['username'];
    }
  }
  programarViaje() {
    this.router.navigate(['/conductor']);
  }

  buscarViaje() {
    this.router.navigate(['/buscar-viaje']);
  }

  verMisViajes() {
    this.router.navigate(['/mis-viajes']);
  }
}