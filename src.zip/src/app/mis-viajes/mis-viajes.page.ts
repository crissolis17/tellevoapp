import { Component, OnInit } from '@angular/core';
import { AutenticacionService } from '../autenticacion.service';
import { ViajesService, Viaje } from '../services/viajes.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-mis-viajes',
  templateUrl: './mis-viajes.page.html',
  styleUrls: ['./mis-viajes.page.scss'],
})
export class MisViajesPage implements OnInit {
  misViajes: Viaje[] = [];
  segmento: string = 'conductor';

  constructor(
    private authService: AutenticacionService,
    private viajesService: ViajesService,
    private alertController: AlertController
  ) {}

  ngOnInit() {
    // Agregar algunos viajes de ejemplo (solo para pruebas)
    this.viajesService.agregarViajesEjemplo();
    this.cargarViajes();
  }

  segmentChanged(event: any) {
    this.segmento = event.detail.value;
    this.cargarViajes();
  }

  async cargarViajes() {
    const userId = this.authService.getUsername();
    if (!userId) {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'No se pudo identificar al usuario',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }

    if (this.segmento === 'conductor') {
      this.misViajes = this.viajesService.getViajesConductor(userId);
    } else {
      this.misViajes = this.viajesService.getViajesPasajero(userId);
    }
  }
}