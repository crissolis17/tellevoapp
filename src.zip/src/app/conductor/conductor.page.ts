import { Component } from '@angular/core';
import { ToastController, AlertController } from '@ionic/angular';
import { ViajesService } from '../services/viajes.service';
import { AutenticacionService } from '../autenticacion.service';

@Component({
  selector: 'app-conductor',
  templateUrl: './conductor.page.html',
  styleUrls: ['./conductor.page.scss'],
})
export class ConductorPage {
  fechaViaje: string = new Date().toISOString();
  origen: string = '';
  destino: string = '';
  asientosDisponibles: number = 1;

  constructor(
    private toastController: ToastController,
    private viajesService: ViajesService,
    private authService: AutenticacionService,
    private alertController: AlertController
  ) {}

  async publicarViaje() {
    // Validaciones
    if (!this.origen || !this.destino) {
      const toast = await this.toastController.create({
        message: 'Por favor, seleccione origen y destino.',
        duration: 2000,
        color: 'danger'
      });
      toast.present();
      return;
    }

    // Validar que origen y destino no sean iguales
    if (this.origen === this.destino) {
      const toast = await this.toastController.create({
        message: 'El origen y destino no pueden ser iguales.',
        duration: 2000,
        color: 'danger'
      });
      toast.present();
      return;
    }

    const conductorId = this.authService.getUsername();
    if (!conductorId) {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'No se pudo identificar al usuario',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }

    // Crear el viaje
    const nuevoViaje = this.viajesService.crearViaje({
      conductorId,
      origen: this.origen,
      destino: this.destino,
      fecha: this.fechaViaje.split('T')[0],
      hora: new Date(this.fechaViaje).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      asientosDisponibles: this.asientosDisponibles
    });

    const toast = await this.toastController.create({
      message: 'Viaje publicado con éxito.',
      duration: 2000,
      color: 'success'
    });
    toast.present();

    // Reiniciar los campos
    this.origen = '';
    this.destino = '';
    this.asientosDisponibles = 1;
    this.fechaViaje = new Date().toISOString();
  }
}