import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pasajero',
  templateUrl: './pasajero.page.html',
  styleUrls: ['./pasajero.page.scss'],
})
export class PasajeroPage implements OnInit {
  // Formulario reactivo
  busquedaForm = new FormGroup({
    fecha: new FormControl(new Date(), Validators.required),
    destino: new FormControl('', Validators.required),
    asientos: new FormControl(1, [Validators.required, Validators.min(1), Validators.max(4)])
  });

  constructor(
    private alertController: AlertController,
    private loadingController: LoadingController,
    private router: Router
  ) {}

  ngOnInit() {}

  async buscarViaje() {
    if (!this.busquedaForm.valid) {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Por favor complete todos los campos',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Buscando viajes disponibles...'
    });
    await loading.present();

    try {
      // Simular búsqueda
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Aquí irían las llamadas a tu servicio de viajes
      
      loading.dismiss();
      // Navegar a resultados o mostrar en la misma página
    } catch (error) {
      loading.dismiss();
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Hubo un error al buscar viajes',
        buttons: ['OK']
      });
      await alert.present();
    }
  }

  limpiarFormulario() {
    this.busquedaForm.reset({
      fecha: new Date(),
      destino: '',
      asientos: 1
    });
  }
}