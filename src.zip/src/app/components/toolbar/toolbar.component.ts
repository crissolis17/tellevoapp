// src/app/components/toolbar/toolbar.component.ts
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AutenticacionService } from '../../autenticacion.service';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})
export class ToolbarComponent {
  
  constructor(
    private router: Router,
    private authService: AutenticacionService
  ) {}

  navegarA(ruta: string) {
    this.router.navigate([ruta]);
  }

  estaLogueado(): boolean {
    return this.authService.estaLogueado();
  }

  cerrarSesion() {
    this.authService.cerrarSesion();
  }
}