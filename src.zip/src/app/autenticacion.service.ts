// src/app/services/autenticacion.service.ts
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService, Usuario } from './services/storage.service'; 

// Asegurarnos de que UsuarioConPassword extienda de Usuario
interface UsuarioConPassword extends Usuario {
password: string; // Ahora password es requerido, no opcional
}

@Injectable({
providedIn: 'root'
})
export class AutenticacionService {
private readonly STORAGE_KEY = 'auth_user';
private readonly USERS_KEY = 'registered_users';
private usuarioLogueado: boolean = false;
private username: string | null = null;

constructor(
private router: Router,
private storageService: StorageService
) {
this.checkSession();
}

private checkSession() {
const userData = localStorage.getItem(this.STORAGE_KEY);
if (userData) {
    const user = JSON.parse(userData);
    this.usuarioLogueado = true;
    this.username = user.username;
}
}

estaLogueado(): boolean {
return this.usuarioLogueado;
}

getUsername(): string | null {
return this.username;
}

registrarUsuario(usuario: Usuario, password: string): boolean {
const usuarios = this.getUsuariosRegistrados();

if (usuarios.some(u => u.email === usuario.email || u.rut === usuario.rut)) {
    return false;
}

const usuarioConPassword: UsuarioConPassword = {
    ...usuario,
    password: password
};

usuarios.push(usuarioConPassword);
localStorage.setItem(this.USERS_KEY, JSON.stringify(usuarios));
return true;
}

iniciarSesion(email: string, password: string): boolean {
const usuarios = this.getUsuariosRegistrados();
const usuario = usuarios.find(u => 
    u.email === email && u.password === password
);

if (usuario) {
    this.usuarioLogueado = true;
    this.username = usuario.email;
    
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify({
    username: usuario.email,
    timestamp: new Date().toISOString()
    }));

    const usuarioSinPassword: Usuario = {
    ...usuario,
    fechaRegistro: new Date(usuario.fechaRegistro) // Asegurarse de que la fecha sea un objeto Date
    };
    delete (usuarioSinPassword as any).password;
    
    this.storageService.saveUserProfile(usuarioSinPassword);
    return true;
}
return false;
}

private getUsuariosRegistrados(): UsuarioConPassword[] {
const usuariosString = localStorage.getItem(this.USERS_KEY);
if (!usuariosString) return [];

const usuarios = JSON.parse(usuariosString);
return usuarios.map((u: UsuarioConPassword) => ({
    ...u,
    fechaRegistro: new Date(u.fechaRegistro) // Convertir la fecha a objeto Date
}));
}

cerrarSesion() {
this.usuarioLogueado = false;
this.username = null;
localStorage.removeItem(this.STORAGE_KEY);
this.storageService.clearUserData();
this.router.navigate(['/home']);
}

emailExiste(email: string): boolean {
const usuarios = this.getUsuariosRegistrados();
return usuarios.some(u => u.email === email);
}

rutExiste(rut: string): boolean {
const usuarios = this.getUsuariosRegistrados();
return usuarios.some(u => u.rut === rut);
}

cambiarContrasena(email: string, nuevaContrasena: string): boolean {
const usuarios = this.getUsuariosRegistrados();
const index = usuarios.findIndex(u => u.email === email);

if (index !== -1) {
    usuarios[index].password = nuevaContrasena;
    localStorage.setItem(this.USERS_KEY, JSON.stringify(usuarios));
    return true;
}
return false;
}
}