import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, NavController, LoadingController } from '@ionic/angular';
import { AutenticacionService } from '../autenticacion.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  email: string = '';
  password: string = '';
  mostrarPassword: boolean = false;

  constructor(
    private router: Router,
    private alertController: AlertController,
    private navCtrl: NavController,
    private authService: AutenticacionService,
    private loadingController: LoadingController
  ) {}

  async onSubmit() {
    if (!this.validarCampos()) {
      return;
    }

    const loading = await this.mostrarLoading();

    try {
      if (this.authService.iniciarSesion(this.email, this.password)) {
        await loading.dismiss();
        this.router.navigate(['/home']);
      } else {
        await loading.dismiss();
        await this.mostrarError('Credenciales inválidas');
      }
    } catch (error) {
      await loading.dismiss();
      await this.mostrarError('Error al iniciar sesión');
    }
  }

  private validarCampos(): boolean {
    if (!this.email || !this.password) {
      this.mostrarError('Por favor, complete todos los campos');
      return false;
    }

    if (!this.validarEmail(this.email)) {
      this.mostrarError('Por favor, ingrese un email válido');
      return false;
    }

    return true;
  }

  private validarEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  goToResetPassword() {
    this.navCtrl.navigateForward('/reset-password');
  }

  toggleMostrarPassword() {
    this.mostrarPassword = !this.mostrarPassword;
  }

  private async mostrarError(mensaje: string) {
    const alert = await this.alertController.create({
      header: 'Error',
      message: mensaje,
      buttons: ['OK'],
      cssClass: 'alert-error'
    });
    await alert.present();
  }

  private async mostrarLoading() {
    const loading = await this.loadingController.create({
      message: 'Iniciando sesión...',
      spinner: 'crescent'
    });
    await loading.present();
    return loading;
  }

  // Método para limpiar espacios en el email
  limpiarEmail() {
    if (this.email) {
      this.email = this.email.trim().toLowerCase();
    }
  }

  // Método para ir al registro
  irARegistro() {
    this.router.navigate(['/registro']);
  }

  // Método para autollenar campos (solo para desarrollo/testing)
  autollenarCampos() {
    this.email = 'test@test.com';
    this.password = '123456';
  }

  // Método para limpiar campos
  limpiarCampos() {
    this.email = '';
    this.password = '';
  }

  // Método para validar mientras el usuario escribe
  validarMientrasEscribe() {
    if (this.email && !this.validarEmail(this.email)) {
      // Podrías mostrar un mensaje de error en tiempo real
      return false;
    }
    return true;
  }
}