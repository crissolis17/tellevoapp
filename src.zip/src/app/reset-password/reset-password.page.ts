import { Component } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
})
export class ResetPasswordPage {
  email: string = '';

  constructor(
    private navCtrl: NavController,
    private alertController: AlertController
  ) {}

  async resetPassword() {
    if (this.email) {
      // En una aplicación real, aquí se enviaría una solicitud al servidor
      // Por ahora, simularemos un restablecimiento exitoso
      const alert = await this.alertController.create({
        header: 'Éxito',
        message: 'Se ha enviado un correo para restablecer su contraseña.',
        buttons: ['OK']
      });

      await alert.present();
      this.navCtrl.navigateBack('/login');
    } else {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Por favor, ingrese su correo electrónico.',
        buttons: ['OK']
      });

      await alert.present();
    }
  }
}