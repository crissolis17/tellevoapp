
export interface Usuario {
    id: string;
    nombre: string;
    apellido: string;
    email: string;
    telefono: string;
    rut: string;
    fotoPerfil?: string;
    vehiculo?: {
    marca: string;
    modelo: string;
    año: number;
    color: string;
    patente: string;
    };
    calificacion: number;
    viajesCompletados: number;
    fechaRegistro: Date;
    esVerificado: boolean;
}