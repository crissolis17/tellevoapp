import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-encontrado',
  templateUrl: './no-encontrado.page.html',
  styleUrls: ['./no-encontrado.page.scss'],
})
export class NoEncontradoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
