import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AutenticacionService } from '../autenticacion.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { SharedModule } from '../shared/shared.module'; 
import { ClimaService } from '../services/clima.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  // Agregar las propiedades que faltaban
  climaActual: any = null;        // Almacena datos del clima
  mostrarDetalles: boolean = false; // Control para mostrar/ocultar detalles
  error: string = '';             // Almacena mensajes de error
  
  constructor(
    public router: Router,
    public authService: AutenticacionService,
    private alertController: AlertController,
    private climaService: ClimaService,
    private loadingCtrl: LoadingController
  ) {}

  ngOnInit() {
    this.obtenerClimaActual();
  }

  // Método para navegar al login
  irALogin() {
    this.router.navigate(['/login']);
  }

  async checkAuth(route: string) {
    if (!this.authService.estaLogueado()) {
      const alert = await this.alertController.create({
        header: 'Acceso Denegado',
        message: 'Debes iniciar sesión para acceder a esta función',
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel'
          },
          {
            text: 'Iniciar Sesión',
            handler: () => {
              this.router.navigate(['/login']);
            }
          }
        ]
      });
      await alert.present();
      return;
    }
    this.router.navigate([route]);
  }

  async obtenerClimaActual() {
    const loading = await this.loadingCtrl.create({
      message: 'Cargando clima...',
      spinner: 'crescent'
    });
    await loading.present();

    this.climaService.obtenerClimaActual()
      .subscribe({
        next: (data) => {
          this.climaActual = data;
          this.error = '';
          loading.dismiss();
        },
        error: (error) => {
          console.error('Error al obtener clima:', error);
          this.error = 'Error al obtener el clima';
          this.climaActual = null;
          loading.dismiss();
        }
      });
  }

  obtenerIconoUrl(iconCode: string): string {
    return this.climaService.obtenerIconoUrl(iconCode);
  }

  toggleDetalles() {
    this.mostrarDetalles = !this.mostrarDetalles;
  }

  goToConductor() {
    this.checkAuth('/conductor');
  }

  goToPasajero() {
    this.checkAuth('/pasajero');
  }

  goToMisViajes() {
    this.checkAuth('/mis-viajes');
  }

  goToApiDelClima() {
    this.router.navigate(['/api-clima']);
  }

  goToApiDelMapa() {
    this.router.navigate(['/api-mapa']);
  }
}