import { Component, OnInit } from '@angular/core';
import { StorageService, Usuario } from '../services/storage.service';
import { AlertController, ToastController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
})
export class PerfilPage implements OnInit {
  usuario: Usuario = {
    id: '',
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    rut: '',
    fotoPerfil: 'assets/default-avatar.png',
    calificacion: 0,
    viajesCompletados: 0,
    fechaRegistro: new Date(),
    esVerificado: false
  };
  modoEdicion: boolean = false;
  usuarioTemp: Partial<Usuario> = {};

  constructor(
    private storageService: StorageService,
    private alertController: AlertController,
    private toastController: ToastController,
    private router: Router
  ) {}

  ngOnInit() {
    this.cargarPerfil();
  }

  cargarPerfil() {
    const perfilGuardado = this.storageService.getUserProfile();
    if (perfilGuardado) {
      this.usuario = perfilGuardado;
    } else {
      this.storageService.initializeDefaultProfile();
      const perfilDefault = this.storageService.getUserProfile();
      if (perfilDefault) {
        this.usuario = perfilDefault;
      }
    }
  }

  async editarInformacionPersonal() {
    const alert = await this.alertController.create({
      header: 'Editar Información Personal',
      inputs: [
        {
          name: 'nombre',
          type: 'text',
          placeholder: 'Nombre',
          value: this.usuario.nombre
        },
        {
          name: 'apellido',
          type: 'text',
          placeholder: 'Apellido',
          value: this.usuario.apellido
        },
        {
          name: 'email',
          type: 'email',
          placeholder: 'Email',
          value: this.usuario.email
        },
        {
          name: 'telefono',
          type: 'tel',
          placeholder: 'Teléfono (+569XXXXXXXX)',
          value: this.usuario.telefono
        },
        {
          name: 'rut',
          type: 'text',
          placeholder: 'RUT (XXXXXXXX-X)',
          value: this.usuario.rut
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Guardar',
          handler: async (data) => {
            if (!this.validarDatosPersonales(data)) {
              return false;
            }
            this.usuarioTemp = {
              ...this.usuario,
              ...data
            };
            await this.guardarCambios();
            return true;  // Añadido el retorno
          }
        }
      ]
    });
    await alert.present();
  }

  async agregarVehiculo() {
    const alert = await this.alertController.create({
      header: 'Información del Vehículo',
      inputs: [
        {
          name: 'marca',
          type: 'text',
          placeholder: 'Marca',
          value: this.usuario.vehiculo?.marca || ''
        },
        {
          name: 'modelo',
          type: 'text',
          placeholder: 'Modelo',
          value: this.usuario.vehiculo?.modelo || ''
        },
        {
          name: 'anio',
          type: 'number',
          placeholder: 'Año',
          min: 1990,
          max: new Date().getFullYear(),
          value: this.usuario.vehiculo?.anio || new Date().getFullYear()
        },
        {
          name: 'color',
          type: 'text',
          placeholder: 'Color',
          value: this.usuario.vehiculo?.color || ''
        },
        {
          name: 'patente',
          type: 'text',
          placeholder: 'Patente (AA1234 o BBBB99)',
          value: this.usuario.vehiculo?.patente || ''
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Guardar',
          handler: async (data) => {
            if (!this.validarDatosVehiculo(data)) {
              return false;
            }
            this.usuarioTemp = {
              ...this.usuario,
              vehiculo: {
                marca: data.marca.toUpperCase(),
                modelo: data.modelo.toUpperCase(),
                anio: parseInt(data.anio),
                color: data.color.toLowerCase(),
                patente: data.patente.toUpperCase()
              }
            };
            await this.guardarCambios();
            return true;  // Añadido el retorno
          }
        }
      ]
    });
    await alert.present();
  }
  async cambiarFotoPerfil() {
    const alert = await this.alertController.create({
      header: 'Cambiar Foto de Perfil',
      message: 'Esta es una simulación. En una app real, aquí iría la funcionalidad de la cámara.',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Seleccionar Foto',
          handler: () => {
            this.usuarioTemp = {
              ...this.usuario,
              fotoPerfil: 'assets/default-avatar.png'
            };
            this.guardarCambios();
          }
        }
      ]
    });
    await alert.present();
  }

  async guardarCambios() {
    try {
      this.usuario = this.storageService.updateUserProfile(this.usuarioTemp);
      this.modoEdicion = false;
      await this.mostrarToast('Perfil actualizado exitosamente');
    } catch (error) {
      await this.mostrarToast('Error al actualizar el perfil', 'danger');
    }
  }

  private validarDatosPersonales(data: any): boolean {
    if (!data.nombre || !data.apellido || !data.email || !data.telefono || !data.rut) {
      this.mostrarToast('Todos los campos son obligatorios', 'danger');
      return false;
    }

    if (!this.validarRUT(data.rut)) {
      this.mostrarToast('RUT inválido', 'danger');
      return false;
    }

    if (!this.validarEmail(data.email)) {
      this.mostrarToast('Email inválido', 'danger');
      return false;
    }

    if (!this.validarTelefono(data.telefono)) {
      this.mostrarToast('Teléfono inválido', 'danger');
      return false;
    }

    return true;
  }

  private validarDatosVehiculo(data: any): boolean {
    if (!data.marca || !data.modelo || !data.color || !data.patente) {
      this.mostrarToast('Todos los campos son obligatorios', 'danger');
      return false;
    }

    const patenteRegex = /^([A-Z]{2}[0-9]{4}|[A-Z]{4}[0-9]{2})$/;
    const patenteLimpia = data.patente.toUpperCase().replace(/[^A-Z0-9]/g, '');
    
    if (!patenteRegex.test(patenteLimpia)) {
      this.mostrarToast('Formato de patente inválido', 'danger');
      return false;
    }

    const anio = parseInt(data.anio);
    const anioActual = new Date().getFullYear();
    if (anio < 1990 || anio > anioActual) {
      this.mostrarToast('Año inválido', 'danger');
      return false;
    }

    return true;
  }

  private validarRUT(rut: string): boolean {
    const rutRegex = /^\d{7,8}-[\dkK]$/;
    return rutRegex.test(rut);
  }

  private validarEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private validarTelefono(telefono: string): boolean {
    const telefonoRegex = /^\+569\d{8}$/;
    return telefonoRegex.test(telefono);
  }

  private async mostrarToast(mensaje: string, color: string = 'success') {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 2000,
      color: color,
      position: 'bottom'
    });
    await toast.present();
  }

  async confirmarCerrarSesion() {
    const alert = await this.alertController.create({
      header: 'Cerrar Sesión',
      message: '¿Estás seguro que deseas cerrar sesión?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Sí, cerrar sesión',
          handler: () => {
            this.cerrarSesion();
          }
        }
      ]
    });
    await alert.present();
  }

  private cerrarSesion() {
    this.storageService.clearUserData();
    this.router.navigate(['/login']);
  }
}