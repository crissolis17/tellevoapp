import { Injectable } from '@angular/core';

export interface Usuario {
  id: string;
  nombre: string;
  apellido: string;
  email: string;
  telefono: string;
  rut: string;
  fotoPerfil?: string;
  vehiculo?: {
    marca: string;
    modelo: string;
    anio: number;
    color: string;
    patente: string;
  };
  calificacion: number;
  viajesCompletados: number;
  fechaRegistro: Date;
  esVerificado: boolean;
}

export interface Viaje {
  id: string;
  conductorId: string;
  origen: string;
  destino: string;
  fecha: string;
  asientosDisponibles: number;
  pasajeros: string[];
  precio?: number;
  estado?: 'pendiente' | 'en_curso' | 'completado' | 'cancelado';
}

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  // Keys para localStorage
  private readonly USER_PROFILE_KEY = 'user_profile';
  private readonly AUTH_KEY = 'auth_token';
  private readonly VIAJES_KEY = 'viajes_data';

  constructor() {}

  // Métodos para el perfil de usuario
  saveUserProfile(profile: Usuario): void {
    localStorage.setItem(this.USER_PROFILE_KEY, JSON.stringify(profile));
  }

  getUserProfile(): Usuario | null {
    const profileData = localStorage.getItem(this.USER_PROFILE_KEY);
    return profileData ? JSON.parse(profileData) : null;
  }

  updateUserProfile(updates: Partial<Usuario>): Usuario {
    const currentProfile = this.getUserProfile();
    if (!currentProfile) {
      throw new Error('No se encontró el perfil del usuario');
    }
    const updatedProfile = { ...currentProfile, ...updates };
    this.saveUserProfile(updatedProfile);
    return updatedProfile;
  }

  initializeDefaultProfile(): void {
    const defaultProfile: Usuario = {
      id: 'default_user',
      nombre: 'Usuario',
      apellido: 'Demo',
      email: 'usuario@demo.com',
      telefono: '+56912345678',
      rut: '12.345.678-9',
      fotoPerfil: 'assets/default-avatar.png',
      calificacion: 5,
      viajesCompletados: 0,
      fechaRegistro: new Date(),
      esVerificado: false
    };
    this.saveUserProfile(defaultProfile);
  }

  // Métodos para autenticación
  saveAuthToken(token: string): void {
    localStorage.setItem(this.AUTH_KEY, token);
  }

  getAuthToken(): string | null {
    return localStorage.getItem(this.AUTH_KEY);
  }

  // Métodos para viajes
  saveViajes(viajes: Viaje[]): void {
    localStorage.setItem(this.VIAJES_KEY, JSON.stringify(viajes));
  }

  getViajes(): Viaje[] {
    const viajes = localStorage.getItem(this.VIAJES_KEY);
    return viajes ? JSON.parse(viajes) : [];
  }

  addViaje(viaje: Viaje): void {
    const viajes = this.getViajes();
    viajes.push(viaje);
    this.saveViajes(viajes);
  }

  updateViaje(viajeId: string, updates: Partial<Viaje>): Viaje {
    const viajes = this.getViajes();
    const index = viajes.findIndex(v => v.id === viajeId);
    if (index === -1) {
      throw new Error('No se encontró el viaje especificado');
    }
    viajes[index] = { ...viajes[index], ...updates };
    this.saveViajes(viajes);
    return viajes[index];
  }

  deleteViaje(viajeId: string): void {
    const viajes = this.getViajes();
    const filteredViajes = viajes.filter(v => v.id !== viajeId);
    this.saveViajes(filteredViajes);
  }

  // Métodos para limpiar datos
  clearAll(): void {
    localStorage.clear();
  }

  clearUserData(): void {
    localStorage.removeItem(this.USER_PROFILE_KEY);
    localStorage.removeItem(this.AUTH_KEY);
  }

  clearViajes(): void {
    localStorage.removeItem(this.VIAJES_KEY);
  }
}