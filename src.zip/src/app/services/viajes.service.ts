import { Injectable } from '@angular/core';

export interface Viaje {
  id: string;
  conductorId: string;
  origen: string;
  destino: string;
  fecha: string;
  hora: string;
  asientosDisponibles: number;
  pasajeros: string[];
  estado: 'pendiente' | 'en_curso' | 'completado' | 'cancelado';
}

@Injectable({
  providedIn: 'root'
})
export class ViajesService {
  private readonly STORAGE_KEY = 'viajes_data';
  private viajes: Viaje[] = [];

  constructor() {
    this.cargarViajes();
  }

  private cargarViajes() {
    const viajesGuardados = localStorage.getItem(this.STORAGE_KEY);
    if (viajesGuardados) {
      this.viajes = JSON.parse(viajesGuardados);
    }
  }

  private guardarViajes() {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.viajes));
  }

  // Método para obtener los viajes donde el usuario es conductor
  getViajesConductor(conductorId: string): Viaje[] {
    return this.viajes.filter(viaje => 
      viaje.conductorId === conductorId
    ).sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  }

  // Método para obtener los viajes donde el usuario es pasajero
  getViajesPasajero(pasajeroId: string): Viaje[] {
    return this.viajes.filter(viaje => 
      viaje.pasajeros.includes(pasajeroId)
    ).sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  }

  // Método para crear un nuevo viaje
  crearViaje(viaje: Omit<Viaje, 'id' | 'estado' | 'pasajeros'>): Viaje {
    const nuevoViaje: Viaje = {
      ...viaje,
      id: Date.now().toString(),
      estado: 'pendiente',
      pasajeros: []
    };

    this.viajes.push(nuevoViaje);
    this.guardarViajes();
    return nuevoViaje;
  }

  // Método para solicitar un viaje como pasajero
  solicitarViaje(viajeId: string, pasajeroId: string): boolean {
    const viaje = this.viajes.find(v => v.id === viajeId);
    if (viaje && viaje.asientosDisponibles > 0 && !viaje.pasajeros.includes(pasajeroId)) {
      viaje.pasajeros.push(pasajeroId);
      viaje.asientosDisponibles--;
      this.guardarViajes();
      return true;
    }
    return false;
  }

  // Método para filtrar viajes disponibles
  filtrarViajes(fecha: string, destino: string): Viaje[] {
    return this.viajes.filter(viaje => {
      const fechaCoincide = viaje.fecha.includes(fecha.split('T')[0]);
      const destinoCoincide = viaje.destino.toLowerCase().includes(destino.toLowerCase());
      const hayAsientosDisponibles = viaje.asientosDisponibles > 0;
      const estaActivo = viaje.estado === 'pendiente';
      
      return fechaCoincide && destinoCoincide && hayAsientosDisponibles && estaActivo;
    });
  }

  // Método para actualizar el estado de un viaje
  actualizarEstadoViaje(viajeId: string, nuevoEstado: Viaje['estado']): boolean {
    const viaje = this.viajes.find(v => v.id === viajeId);
    if (viaje) {
      viaje.estado = nuevoEstado;
      this.guardarViajes();
      return true;
    }
    return false;
  }

  // Método para cancelar un viaje
  cancelarViaje(viajeId: string, userId: string): boolean {
    const viaje = this.viajes.find(v => v.id === viajeId);
    if (viaje) {
      if (viaje.conductorId === userId) {
        // Si es el conductor, cancela el viaje completamente
        viaje.estado = 'cancelado';
      } else {
        // Si es un pasajero, solo lo elimina de la lista de pasajeros
        const index = viaje.pasajeros.indexOf(userId);
        if (index > -1) {
          viaje.pasajeros.splice(index, 1);
          viaje.asientosDisponibles++;
        }
      }
      this.guardarViajes();
      return true;
    }
    return false;
  }

  // Método para obtener un viaje específico
  getViaje(viajeId: string): Viaje | undefined {
    return this.viajes.find(v => v.id === viajeId);
  }

  // Método para agregar algunos viajes de ejemplo (útil para pruebas)
  agregarViajesEjemplo() {
    const viajesEjemplo: Viaje[] = [
      {
        id: '1',
        conductorId: 'cristian',
        origen: 'Universidad',
        destino: 'Centro',
        fecha: '2024-01-20',
        hora: '18:00',
        asientosDisponibles: 3,
        pasajeros: [],
        estado: 'pendiente'
      },
      {
        id: '2',
        conductorId: 'cristian',
        origen: 'Centro',
        destino: 'Universidad',
        fecha: '2024-01-21',
        hora: '08:00',
        asientosDisponibles: 2,
        pasajeros: [],
        estado: 'pendiente'
      }
    ];

    this.viajes = [...this.viajes, ...viajesEjemplo];
    this.guardarViajes();
  }
}