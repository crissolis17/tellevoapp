import { TestBed } from '@angular/core/testing';

import { AuthionicService } from './authionic.service';

describe('AuthionicService', () => {
  let service: AuthionicService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthionicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
