import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';
import { AutenticacionService } from '../autenticacion.service';
import { Usuario } from '../services/storage.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage {
  nuevoUsuario: Partial<Usuario> = {
    id: '',
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    rut: '',
    calificacion: 5,
    viajesCompletados: 0,
    fechaRegistro: new Date(),
    esVerificado: false,
    fotoPerfil: 'assets/default-avatar.png'
  };

  password: string = '';
  confirmPassword: string = '';

  constructor(
    private router: Router,
    private authService: AutenticacionService,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  async registrar() {
    if (!this.validarFormulario()) {
      return;
    }

    // Verificar si el email o RUT ya están registrados
    if (this.authService.emailExiste(this.nuevoUsuario.email!)) {
      await this.mostrarError('El email ya está registrado');
      return;
    }

    if (this.authService.rutExiste(this.nuevoUsuario.rut!)) {
      await this.mostrarError('El RUT ya está registrado');
      return;
    }

    try {
      const userId = 'user_' + new Date().getTime();
      const nuevoUsuarioCompleto: Usuario = {
        ...this.nuevoUsuario as Usuario,
        id: userId
      };

      // Registrar el usuario
      if (this.authService.registrarUsuario(nuevoUsuarioCompleto, this.password)) {
        await this.mostrarToast('Registro exitoso');
        this.router.navigate(['/login']);
      } else {
        await this.mostrarError('Error al registrar usuario');
      }
    } catch (error) {
      await this.mostrarError('Error al registrar usuario');
    }
  }

  private validarFormulario(): boolean {
    // Validar campos requeridos
    if (!this.nuevoUsuario.nombre || !this.nuevoUsuario.apellido || 
        !this.nuevoUsuario.email || !this.nuevoUsuario.telefono || 
        !this.nuevoUsuario.rut || !this.password || !this.confirmPassword) {
      this.mostrarError('Todos los campos son requeridos');
      return false;
    }

    // Validar RUT
    if (!this.validarRUT(this.nuevoUsuario.rut)) {
      this.mostrarError('RUT inválido. Formato requerido: 12345678-9');
      return false;
    }

    // Validar email
    if (!this.validarEmail(this.nuevoUsuario.email)) {
      this.mostrarError('Email inválido');
      return false;
    }

    // Validar teléfono
    if (!this.validarTelefono(this.nuevoUsuario.telefono)) {
      this.mostrarError('Teléfono inválido. Debe comenzar con +569 seguido de 8 dígitos');
      return false;
    }

    // Validar contraseña
    if (this.password !== this.confirmPassword) {
      this.mostrarError('Las contraseñas no coinciden');
      return false;
    }

    if (this.password.length < 6) {
      this.mostrarError('La contraseña debe tener al menos 6 caracteres');
      return false;
    }

    return true;
  }

  private validarRUT(rut: string): boolean {
    // Implementar validación de RUT chileno
    const rutRegex = /^\d{7,8}-[\dkK]$/;
    return rutRegex.test(rut);
  }

  private validarEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private validarTelefono(telefono: string): boolean {
    const telefonoRegex = /^\+569\d{8}$/;
    return telefonoRegex.test(telefono);
  }

  private async mostrarError(mensaje: string) {
    const alert = await this.alertController.create({
      header: 'Error',
      message: mensaje,
      buttons: ['OK']
    });
    await alert.present();
  }

  private async mostrarToast(mensaje: string) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 2000,
      color: 'success',
      position: 'bottom'
    });
    await toast.present();
  }

  // Método para limpiar espacios en blanco y dar formato al RUT
  formatearRUT() {
    if (this.nuevoUsuario.rut) {
      // Eliminar espacios en blanco y caracteres especiales
      let rutLimpio = this.nuevoUsuario.rut.replace(/[^0-9kK-]/g, '');
      
      // Verificar si ya tiene guión
      if (!rutLimpio.includes('-')) {
        // Si no tiene guión y tiene el largo adecuado, añadirlo
        if (rutLimpio.length >= 2) {
          rutLimpio = rutLimpio.slice(0, -1) + '-' + rutLimpio.slice(-1);
        }
      }
      
      this.nuevoUsuario.rut = rutLimpio;
    }
  }

  // Método para formatear el teléfono
  formatearTelefono() {
    if (this.nuevoUsuario.telefono) {
      // Eliminar espacios y caracteres especiales
      let telefonoLimpio = this.nuevoUsuario.telefono.replace(/[^0-9]/g, '');
      
      // Si no comienza con +569, agregarlo
      if (!this.nuevoUsuario.telefono.startsWith('+569')) {
        telefonoLimpio = '+569' + telefonoLimpio;
      }
      
      // Limitar a 12 caracteres (+569 + 8 dígitos)
      telefonoLimpio = telefonoLimpio.slice(0, 12);
      
      this.nuevoUsuario.telefono = telefonoLimpio;
    }
  }
}