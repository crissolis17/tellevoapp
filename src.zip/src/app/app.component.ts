// src/app/app.component.ts
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AutenticacionService } from './autenticacion.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    private router: Router,
    private authService: AutenticacionService
  ) {}

  navegarA(ruta: string) {
    this.router.navigate([ruta]);
  }

  estaLogueado(): boolean {
    return this.authService.estaLogueado();
  }
}